import { useState } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { Webhook } from "@shared/schema";
import { Button } from "@/components/ui/button";
import { ArrowLeft, Download, Trash2 } from "lucide-react";
import { Link } from "wouter";
import { useToast } from "@/hooks/use-toast";
import { apiRequest, queryClient } from "@/lib/queryClient";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog";

export default function WebhookDetails({ params }: { params: { id: string } }) {
  const { toast } = useToast();
  const [deleteResponseIndex, setDeleteResponseIndex] = useState<number | null>(null);

  const { data: webhook, isLoading } = useQuery<Webhook>({
    queryKey: [`/api/webhooks/${params.id}`],
  });

  const deleteResponseMutation = useMutation({
    mutationFn: async ({ webhookId, responseIndex }: { webhookId: number; responseIndex: number }) => {
      await apiRequest("DELETE", `/api/webhooks/${webhookId}/responses/${responseIndex}`);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: [`/api/webhooks/${params.id}`] });
      toast({
        title: "Antwort gelöscht",
        description: "Die Antwort wurde erfolgreich gelöscht.",
      });
    },
  });

  if (isLoading) {
    return (
      <div className="flex justify-center items-center min-h-screen">
        <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary" />
      </div>
    );
  }

  if (!webhook) {
    return (
      <div className="container mx-auto p-6">
        <h1 className="text-2xl font-bold mb-4">Webhook nicht gefunden</h1>
        <Button asChild>
          <Link href="/webhooks">Zurück zur Übersicht</Link>
        </Button>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background">
      <div className="container mx-auto p-6">
        <Button variant="ghost" asChild className="mb-6">
          <Link href="/webhooks">
            <ArrowLeft className="mr-2 h-4 w-4" />
            Zurück zur Übersicht
          </Link>
        </Button>

        <div className="mb-8">
          <h1 className="text-3xl font-bold">{webhook.name}</h1>
          <p className="text-muted-foreground mt-1">
            Form ID: {webhook.typeformId} | Empfänger: {webhook.recipientEmail}
          </p>
        </div>

        <div className="rounded-md border">
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>Datum</TableHead>
                <TableHead>Fallnummer</TableHead>
                <TableHead>Antworten</TableHead>
                <TableHead>Dokumente</TableHead>
                <TableHead className="text-right">Aktionen</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {webhook.responses?.map((response, index) => (
                <TableRow key={index}>
                  <TableCell>
                    {new Date(response.timestamp).toLocaleString()}
                  </TableCell>
                  <TableCell className="font-medium">
                    {response.fallnummer}
                  </TableCell>
                  <TableCell>
                    <div className="max-h-32 overflow-y-auto">
                      {response.answers.map((answer, i) => (
                        <div key={i} className="text-sm">
                          <span className="font-medium">{answer.question}:</span>{" "}
                          {answer.answer}
                        </div>
                      ))}
                    </div>
                  </TableCell>
                  <TableCell>
                    <div className="flex gap-2">
                      {response.docxPath && (
                        <Button
                          variant="outline"
                          size="sm"
                          asChild
                        >
                          <a
                            href={`/api/documents/${response.fallnummer}.docx`}
                            download
                          >
                            <Download className="h-4 w-4 mr-2" />
                            DOCX
                          </a>
                        </Button>
                      )}
                      {response.pdfPath && (
                        <Button
                          variant="outline"
                          size="sm"
                          asChild
                        >
                          <a
                            href={`/api/documents/${response.fallnummer}.pdf`}
                            download
                          >
                            <Download className="h-4 w-4 mr-2" />
                            PDF
                          </a>
                        </Button>
                      )}
                    </div>
                  </TableCell>
                  <TableCell className="text-right">
                    <Button
                      variant="destructive"
                      size="sm"
                      onClick={() => setDeleteResponseIndex(index)}
                    >
                      <Trash2 className="h-4 w-4" />
                    </Button>
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </div>

        <AlertDialog open={deleteResponseIndex !== null} onOpenChange={() => setDeleteResponseIndex(null)}>
          <AlertDialogContent>
            <AlertDialogHeader>
              <AlertDialogTitle>Antwort löschen</AlertDialogTitle>
              <AlertDialogDescription>
                Möchten Sie diese Antwort wirklich löschen? Diese Aktion kann nicht rückgängig gemacht werden.
              </AlertDialogDescription>
            </AlertDialogHeader>
            <AlertDialogFooter>
              <AlertDialogCancel>Abbrechen</AlertDialogCancel>
              <AlertDialogAction
                onClick={() => {
                  if (deleteResponseIndex !== null) {
                    deleteResponseMutation.mutate({
                      webhookId: webhook.id,
                      responseIndex: deleteResponseIndex,
                    });
                    setDeleteResponseIndex(null);
                  }
                }}
              >
                Löschen
              </AlertDialogAction>
            </AlertDialogFooter>
          </AlertDialogContent>
        </AlertDialog>
      </div>
    </div>
  );
}
