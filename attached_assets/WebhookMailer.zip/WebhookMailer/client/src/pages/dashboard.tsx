import { useAuth } from "@/hooks/use-auth";
import { useQuery } from "@tanstack/react-query";
import { Webhook } from "@shared/schema";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Loader2, Bell, Settings, BellRing } from "lucide-react";
import { Link } from "wouter";
import { Navigation } from "@/components/navigation";

export default function Dashboard() {
  const { user } = useAuth();
  const { data: webhooks, isLoading } = useQuery<Webhook[]>({
    queryKey: ["/api/webhooks"],
  });

  const activeWebhooks = webhooks?.filter(w => w.active).length || 0;
  const totalWebhooks = webhooks?.length || 0;

  return (
    <div className="min-h-screen bg-background">
      <Navigation />

      <div className="container mx-auto p-6">
        <div className="flex items-center justify-between mb-8">
          <div>
            <h1 className="text-3xl font-bold">Welcome, {user?.username}!</h1>
            <p className="text-muted-foreground mt-1">
              {user?.isAdmin ? "Administrator Dashboard" : "Manage your Typeform webhook notifications"}
            </p>
          </div>
          <Button asChild>
            <Link href="/webhooks">
              <Bell className="mr-2 h-4 w-4" />
              Manage Webhooks
            </Link>
          </Button>
        </div>

        {isLoading ? (
          <div className="flex justify-center my-12">
            <Loader2 className="h-8 w-8 animate-spin text-primary" />
          </div>
        ) : (
          <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3">
            <Card>
              <CardHeader>
                <CardTitle className="text-lg font-medium">
                  Active Webhooks
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="flex items-center">
                  <BellRing className="h-8 w-8 text-primary mr-4" />
                  <div>
                    <p className="text-2xl font-bold">{activeWebhooks}</p>
                    <p className="text-sm text-muted-foreground">
                      out of {totalWebhooks} total
                    </p>
                  </div>
                </div>
              </CardContent>
            </Card>

            {webhooks?.slice(0, 2).map((webhook) => (
              <Card key={webhook.id}>
                <CardHeader>
                  <CardTitle className="text-lg font-medium truncate">
                    {webhook.name}
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-2">
                    <p className="text-sm text-muted-foreground">
                      Form ID: {webhook.typeformId}
                    </p>
                    <p className="text-sm text-muted-foreground">
                      Recipient: {webhook.recipientEmail}
                    </p>
                    <div className="flex items-center mt-4">
                      <div
                        className={`h-2 w-2 rounded-full mr-2 ${
                          webhook.active ? "bg-green-500" : "bg-gray-300"
                        }`}
                      />
                      <span className="text-sm">
                        {webhook.active ? "Active" : "Inactive"}
                      </span>
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        )}

        {webhooks?.length === 0 && (
          <Card className="mt-6">
            <CardContent className="flex flex-col items-center justify-center py-12">
              <Bell className="h-12 w-12 text-muted-foreground mb-4" />
              <h3 className="text-lg font-medium mb-2">No Webhooks Yet</h3>
              <p className="text-muted-foreground text-center mb-4">
                Get started by creating your first webhook to receive form notifications
              </p>
              <Button asChild>
                <Link href="/webhooks">Create Webhook</Link>
              </Button>
            </CardContent>
          </Card>
        )}
      </div>
    </div>
  );
}