import { useState } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { Webhook, insertWebhookSchema } from "@shared/schema";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription } from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { Loader2, Plus, Copy } from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import { queryClient } from "@/lib/queryClient";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";

export default function WebhooksPage() {
  const [isDialogOpen, setIsDialogOpen] = useState(false);
  const { toast } = useToast();

  const { data: webhooks, isLoading } = useQuery<Webhook[]>({
    queryKey: ["/api/webhooks"],
  });

  const form = useForm({
    resolver: zodResolver(insertWebhookSchema),
    defaultValues: {
      name: "",
      formId: "",
      recipientEmail: "",
      emailSubject: "",
    },
  });

  // Create webhook mutation
  const createWebhookMutation = useMutation({
    mutationFn: async (data: any) => {
      const res = await fetch("/api/webhooks", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(data),
      });
      if (!res.ok) {
        const error = await res.json();
        throw new Error(error.message || "Failed to create webhook");
      }
      return res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/webhooks"] });
      setIsDialogOpen(false);
      form.reset();
      toast({
        title: "Webhook erstellt",
        description: "Der Webhook wurde erfolgreich erstellt.",
      });
    },
    onError: (error: any) => {
      toast({
        title: "Fehler",
        description: error.message || "Der Webhook konnte nicht erstellt werden.",
        variant: "destructive",
      });
    },
  });

  const onSubmit = async (data: any) => {
    try {
      await createWebhookMutation.mutateAsync(data);
    } catch (error) {
      console.error("Mutation error:", error);
    }
  };

  return (
    <div className="container mx-auto p-6">
      {/* Header */}
      <div className="flex items-center justify-between mb-6">
        <h1 className="text-2xl font-bold">Webhooks</h1>
        <Button onClick={() => setIsDialogOpen(true)} className="gap-2">
          <Plus className="h-4 w-4" />
          Neuen Webhook erstellen
        </Button>
      </div>

      {/* Webhook Form Dialog */}
      <Dialog open={isDialogOpen} onOpenChange={setIsDialogOpen}>
        <DialogContent className="sm:max-w-[425px]">
          <DialogHeader>
            <DialogTitle>Webhook erstellen</DialogTitle>
            <DialogDescription>
              Füllen Sie die folgenden Felder aus, um einen neuen Webhook zu erstellen.
            </DialogDescription>
          </DialogHeader>
          <Form {...form}>
            <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4">
              <FormField
                control={form.control}
                name="name"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Name des Webhooks</FormLabel>
                    <FormControl>
                      <Input {...field} placeholder="z.B. Feedback-Formular" />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
              <FormField
                control={form.control}
                name="formId"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Typeform ID</FormLabel>
                    <FormControl>
                      <Input {...field} placeholder="z.B. abc123" />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
              <FormField
                control={form.control}
                name="recipientEmail"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Empfänger E-Mail</FormLabel>
                    <FormControl>
                      <Input {...field} type="email" placeholder="benachrichtigungen@beispiel.de" />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
              <FormField
                control={form.control}
                name="emailSubject"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>E-Mail Betreff</FormLabel>
                    <FormControl>
                      <Input {...field} placeholder="Neue Formular-Antwort" />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
              <Button
                type="submit"
                className="w-full"
                disabled={createWebhookMutation.isPending}
              >
                {createWebhookMutation.isPending && (
                  <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                )}
                Webhook erstellen
              </Button>
            </form>
          </Form>
        </DialogContent>
      </Dialog>

      {/* List of Webhooks */}
      {isLoading ? (
        <div className="flex justify-center my-12">
          <Loader2 className="h-8 w-8 animate-spin text-primary" />
        </div>
      ) : webhooks?.length === 0 ? (
        <Card>
          <CardContent className="flex flex-col items-center justify-center py-12">
            <h3 className="text-lg font-medium mb-4">Erstellen Sie Ihren ersten Webhook</h3>
            <p className="text-muted-foreground text-center mb-8 max-w-md">
              Mit Webhooks können Sie automatisch E-Mail-Benachrichtigungen für neue Typeform-Antworten erhalten.
            </p>
            <Button onClick={() => setIsDialogOpen(true)}>
              <Plus className="mr-2 h-4 w-4" />
              Neuen Webhook erstellen
            </Button>
          </CardContent>
        </Card>
      ) : (
        <div className="space-y-6">
          {/* Webhooks Table */}
          <div className="rounded-md border">
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Name</TableHead>
                  <TableHead>Form ID</TableHead>
                  <TableHead>Empfänger</TableHead>
                  <TableHead>Letzte Antwort</TableHead>
                  <TableHead className="text-right">Webhook URL</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {webhooks?.map((webhook) => (
                  <TableRow key={webhook.id}>
                    <TableCell className="font-medium">{webhook.name}</TableCell>
                    <TableCell>{webhook.formId}</TableCell>
                    <TableCell>{webhook.recipientEmail}</TableCell>
                    <TableCell>
                      {webhook.lastResponseTime ? (
                        new Date(webhook.lastResponseTime).toLocaleString()
                      ) : (
                        <span className="text-muted-foreground">Keine Antworten</span>
                      )}
                    </TableCell>
                    <TableCell className="text-right">
                      <Button
                        variant="outline"
                        size="sm"
                        onClick={() => {
                          const webhookUrl = `${window.location.origin}/api/webhook/${webhook.id}/receive`;
                          navigator.clipboard.writeText(webhookUrl);
                          toast({
                            title: "URL kopiert",
                            description: "Die Webhook-URL wurde in die Zwischenablage kopiert.",
                          });
                        }}
                        className="gap-2"
                      >
                        <Copy className="h-4 w-4" />
                        URL kopieren
                      </Button>
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </div>

          {/* Responses for each webhook */}
          {webhooks?.map((webhook) => (
            <div key={`responses-${webhook.id}`} className="rounded-md border">
              <div className="p-4 border-b">
                <h3 className="text-lg font-medium">Antworten für {webhook.name}</h3>
              </div>
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Datum</TableHead>
                    <TableHead>Fallnummer</TableHead>
                    <TableHead>Antworten</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {webhook.responses?.map((response) => (
                    <TableRow key={response.fallnummer}>
                      <TableCell>{new Date(response.timestamp).toLocaleString()}</TableCell>
                      <TableCell>{response.fallnummer}</TableCell>
                      <TableCell>
                        <ul className="list-disc list-inside">
                          {response.answers.map((answer, index) => (
                            <li key={index} className="text-sm">
                              <span className="font-medium">{answer.question}:</span>{" "}
                              {answer.answer}
                            </li>
                          ))}
                        </ul>
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}