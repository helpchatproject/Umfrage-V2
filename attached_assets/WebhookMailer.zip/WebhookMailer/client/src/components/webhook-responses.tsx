import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Webhook } from "@shared/schema";

interface WebhookResponsesProps {
  webhook: Webhook;
}

export function WebhookResponses({ webhook }: WebhookResponsesProps) {
  return (
    <div className="rounded-md border">
      <div className="p-4 border-b">
        <h3 className="text-lg font-medium">Antworten für {webhook.name}</h3>
      </div>
      <Table>
        <TableHeader>
          <TableRow>
            <TableHead>Datum</TableHead>
            <TableHead>Fallnummer</TableHead>
            <TableHead>Antworten</TableHead>
          </TableRow>
        </TableHeader>
        <TableBody>
          {webhook.responses?.map((response) => (
            <TableRow key={response.fallnummer}>
              <TableCell>{new Date(response.timestamp).toLocaleString()}</TableCell>
              <TableCell>{response.fallnummer}</TableCell>
              <TableCell>
                <ul className="list-disc list-inside">
                  {response.answers.map((answer, index) => (
                    <li key={index} className="text-sm">
                      <span className="font-medium">{answer.question}:</span>{" "}
                      {answer.answer}
                    </li>
                  ))}
                </ul>
              </TableCell>
            </TableRow>
          ))}
        </TableBody>
      </Table>
    </div>
  );
}
