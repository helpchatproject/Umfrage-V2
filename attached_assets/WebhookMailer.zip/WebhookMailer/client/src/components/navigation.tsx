import { Button } from "@/components/ui/button";
import { useAuth } from "@/hooks/use-auth";
import { Settings, LogOut } from "lucide-react";
import { Link } from "wouter";

export function Navigation() {
  const { user, logoutMutation } = useAuth();

  return (
    <div className="border-b">
      <div className="container mx-auto px-6 py-4">
        <div className="flex items-center justify-between">
          <div className="flex items-center space-x-4">
            <Link href="/" className="text-xl font-bold">
              Webhook Manager
            </Link>
          </div>
          <div className="flex items-center space-x-4">
            {user?.isAdmin && (
              <Button variant="outline" asChild>
                <Link href="/smtp-settings">
                  <Settings className="h-4 w-4 mr-2" />
                  SMTP Settings
                </Link>
              </Button>
            )}
            <Button
              variant="ghost"
              onClick={() => logoutMutation.mutate()}
              disabled={logoutMutation.isPending}
            >
              <LogOut className="h-4 w-4 mr-2" />
              Logout
            </Button>
          </div>
        </div>
      </div>
    </div>
  );
}