import { pgTable, text, serial, integer, boolean, jsonb, timestamp } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

// Basic webhook configuration
export const webhooks = pgTable("webhooks", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  formId: text("form_id").notNull(),
  recipientEmail: text("recipient_email").notNull(),
  emailSubject: text("email_subject").notNull(),
  responses: jsonb("responses").default([]),
  lastResponseTime: timestamp("last_response_time"),
  createdAt: timestamp("created_at").defaultNow(),
});

// Schema for creating new webhooks
export const insertWebhookSchema = z.object({
  name: z.string().min(1, "Name ist erforderlich"),
  formId: z.string().min(1, "Typeform ID ist erforderlich"),
  recipientEmail: z.string().email("Gültige E-Mail-Adresse erforderlich"),
  emailSubject: z.string().min(1, "E-Mail-Betreff ist erforderlich"),
});

// Types for our webhook data
export type Webhook = typeof webhooks.$inferSelect;
export type InsertWebhook = z.infer<typeof insertWebhookSchema>;

// Types for form responses
export interface FormAnswer {
  question: string;
  answer: string;
}

export interface WebhookResponse {
  timestamp: Date;
  fallnummer: string;
  answers: FormAnswer[];
}