import type { Express } from "express";
import { storage } from "./storage";
import { insertWebhookSchema } from "@shared/schema";
import { WebSocketServer, WebSocket } from 'ws';
import { createServer, type Server } from "http";
import { setupAuth } from "./auth";
import { sendEmail } from "./email";

export async function registerRoutes(app: Express): Promise<Server> {
  const httpServer = createServer(app);
  const wss = new WebSocketServer({ server: httpServer, path: '/ws' });

  // WebSocket broadcast function
  function broadcastUpdate() {
    wss.clients.forEach((client) => {
      if (client.readyState === WebSocket.OPEN) {
        client.send(JSON.stringify({ type: 'WEBHOOK_UPDATE' }));
      }
    });
  }

  // Get all webhooks
  app.get("/api/webhooks", async (req, res) => {
    try {
      const webhooks = await storage.getAllWebhooks();
      res.json(webhooks);
    } catch (error) {
      console.error('Error fetching webhooks:', error);
      res.status(500).json({ error: "Failed to fetch webhooks" });
    }
  });

  // Create a new webhook
  app.post("/api/webhooks", async (req, res) => {
    try {
      const webhookData = insertWebhookSchema.parse(req.body);
      const webhook = await storage.createWebhook(webhookData);
      broadcastUpdate();
      res.status(201).json(webhook);
    } catch (error) {
      console.error('Error creating webhook:', error);
      res.status(400).json({ error: error instanceof Error ? error.message : "Invalid webhook data" });
    }
  });

  // Webhook endpoint to receive Typeform data
  app.post("/api/webhook/:id/receive", async (req, res) => {
    try {
      console.log('Webhook request received:', {
        params: req.params,
        body: req.body
      });

      const webhook = await storage.getWebhook(parseInt(req.params.id));
      if (!webhook) {
        return res.status(404).json({ error: "Webhook nicht gefunden" });
      }

      const formResponse = req.body.form_response;
      if (!formResponse) {
        return res.status(400).json({ error: "Keine Formularantwort gefunden" });
      }

      // Process the answers from Typeform
      const answers = formResponse.answers.map((answer: any) => ({
        question: answer.field?.title || 'Unbekannte Frage',
        answer: answer.text || answer.email || answer.number?.toString() || 
                answer.choice?.label || answer.choices?.labels?.join(', ') || 
                (answer.boolean ? 'Ja' : 'Nein') || ''
      }));

      // Create response object with unique case number
      const response = {
        timestamp: new Date(),
        fallnummer: `CASE-${Date.now()}`,
        answers
      };

      // Store the response
      await storage.addResponse(webhook.id, response);

      // Notify connected clients via WebSocket
      broadcastUpdate();

      res.status(200).json({
        message: "Webhook-Antwort erfolgreich verarbeitet",
        fallnummer: response.fallnummer,
        timestamp: response.timestamp
      });
    } catch (error) {
      console.error('Error processing webhook:', error);
      res.status(500).json({ error: "Interner Server-Fehler bei der Verarbeitung des Webhooks" });
    }
  });

  // Setup authentication after webhook endpoint
  setupAuth(app);

  // Protected routes below this point
  app.use((req, res, next) => {
    if (!req.isAuthenticated()) {
      return res.status(401).json({ error: "Nicht authentifiziert" });
    }
    next();
  });


  // Webhook management routes (from original code, adjusted to use new storage methods if necessary)
  app.patch("/api/webhooks/:id", async (req, res) => {
    const webhook = await storage.getWebhook(parseInt(req.params.id));
    if (!webhook || webhook.userId !== req.user.id) {
      return res.sendStatus(404);
    }

    try {
      const updatedData = insertWebhookSchema.partial().parse(req.body);
      const updated = await storage.updateWebhook(webhook.id, updatedData);
      broadcastUpdate();
      res.json(updated);
    } catch (error) {
      if (error instanceof Error) {
        res.status(400).json({ error: error.message });
      } else {
        res.status(400).json({ error: "Invalid webhook data" });
      }
    }
  });

  app.delete("/api/webhooks/:id", async (req, res) => {
    const webhook = await storage.getWebhook(parseInt(req.params.id));
    if (!webhook || webhook.userId !== req.user.id) {
      return res.sendStatus(404);
    }

    await storage.deleteWebhook(webhook.id);
    broadcastUpdate();
    res.sendStatus(204);
  });

  app.get("/api/webhooks/:id", async (req, res) => {
    const webhook = await storage.getWebhook(parseInt(req.params.id));
    if (!webhook || webhook.userId !== req.user.id) {
      return res.sendStatus(404);
    }

    res.json(webhook);
  });

  app.post("/api/webhook/:id/test", async (req, res) => {
    const webhook = await storage.getWebhook(parseInt(req.params.id));
    if (!webhook || webhook.userId !== req.user.id) {
      return res.sendStatus(404);
    }

    const success = await sendEmail({
      to: webhook.recipientEmail,
      subject: `[TEST] ${webhook.emailSubject}`,
      html: webhook.testMessage || "This is a test message from your webhook."
    });

    if (success) {
      res.sendStatus(200);
    } else {
      res.status(500).json({ error: "Failed to send test email" });
    }
  });

  app.delete("/api/webhooks/:id/responses/:index", async (req, res) => {
    const webhook = await storage.getWebhook(parseInt(req.params.id));
    if (!webhook || webhook.userId !== req.user.id) {
      return res.sendStatus(404);
    }

    try {
      const responses = webhook.responses || [];
      const index = parseInt(req.params.index);

      if (index < 0 || index >= responses.length) {
        return res.status(400).json({ error: "Invalid response index" });
      }

      responses.splice(index, 1);

      await storage.updateWebhook(webhook.id, {
        responses: responses,
      });

      broadcastUpdate();
      res.sendStatus(200);
    } catch (error) {
      console.error('Error deleting response:', error);
      res.status(500).json({ error: "Internal server error" });
    }
  });

  return httpServer;
}