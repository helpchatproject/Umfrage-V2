import { Document, Packer, Paragraph, TextRun } from 'docx';
import { PDFDocument, StandardFonts } from 'pdf-lib';
import fs from 'fs/promises';
import path from 'path';

interface FormAnswer {
  question: string;
  answer: string;
}

export async function generateDocument(answers: FormAnswer[], fallnummer: string) {
  try {
    // Get the actual fallnummer from the first answer (which should be the fallnummer field)
    const actualFallnummer = answers.find(a => a.question.includes('Fallnummer'))?.answer || fallnummer;

    // Get current date and time in the correct format
    const now = new Date();
    const dateString = `${now.getFullYear()}-${String(now.getMonth() + 1).padStart(2, '0')}-${String(now.getDate()).padStart(2, '0')} ${String(now.getHours()).padStart(2, '0')}:${String(now.getMinutes()).padStart(2, '0')}:${String(now.getSeconds()).padStart(2, '0')}`;

    // Create a new document
    const doc = new Document({
      sections: [{
        properties: {},
        children: [
          new Paragraph({
            children: [
              new TextRun({
                text: `Fallnummer: F${actualFallnummer}`,
                bold: true,
              }),
            ],
          }),
          new Paragraph({
            children: [
              new TextRun({
                text: "Ausfülldatum: " + dateString,
                bold: true,
              }),
            ],
            spacing: {
              after: 400,
            },
          }),
          ...answers.filter(qa => !qa.question.includes('Fallnummer')).map((qa) => {
            // Format answer based on type
            let formattedAnswer = qa.answer;
            if (qa.answer === 'Ja' || qa.answer === 'Nein' || qa.answer === 'Test') {
              formattedAnswer = `"${qa.answer}"`;
            }

            if (qa.question === "Praktische Probleme" || qa.question === "Familiäre Probleme" || qa.question === "Emotionale Probleme") {
              return new Paragraph({
                children: [
                  new TextRun({
                    text: `${qa.question}:`,
                    bold: true,
                  }),
                ],
                spacing: {
                  before: 400,
                  after: 200,
                },
              });
            }

            // Check if this is a sub-item that needs indentation
            const needsIndent = [
              'Wohnsituation',
              'Versicherung',
              'Arbeit/Schule',
              'Beförderung/Transport',
              'Kinderbetreuung',
              'Im Umgang mit dem Partner',
              'Im Umgang mit den Kindern',
              'Haben Sie minderjährige Kinder',
              'Sorgen',
              'Ängste',
              'Traurigkeit',
            ].some(item => qa.question.includes(item));

            return new Paragraph({
              children: [
                new TextRun({
                  text: qa.question,
                  bold: true,
                }),
                new TextRun({
                  text: `: ${formattedAnswer}`,
                }),
              ],
              spacing: {
                before: 200,
                after: 200,
              },
              indent: {
                left: needsIndent ? 720 : 0,
              },
            });
          }),
        ],
      }],
    });

    // Ensure the uploads directory exists
    const uploadsDir = path.join(process.cwd(), 'uploads');
    await fs.mkdir(uploadsDir, { recursive: true });

    // Generate docx with the actual fallnummer as filename
    const docxBuffer = await Packer.toBuffer(doc);
    const docxPath = path.join(uploadsDir, `${actualFallnummer}.docx`);
    await fs.writeFile(docxPath, docxBuffer);

    // Create PDF with the same content
    const pdfDoc = await PDFDocument.create();
    const page = pdfDoc.addPage();
    const font = await pdfDoc.embedFont(StandardFonts.HelveticaBold);
    const regularFont = await pdfDoc.embedFont(StandardFonts.Helvetica);

    // Add fallnummer to PDF
    page.drawText(`Fallnummer: F${actualFallnummer}`, {
      x: 50,
      y: page.getHeight() - 50,
      size: 14,
      font,
    });

    // Add Ausfülldatum
    page.drawText(`Ausfülldatum: ${dateString}`, {
      x: 50,
      y: page.getHeight() - 80,
      size: 14,
      font,
    });

    let yOffset = 120;
    let currentSection = "";

    for (const qa of answers.filter(qa => !qa.question.includes('Fallnummer'))) {
      // Format answer based on type
      let formattedAnswer = qa.answer;
      if (qa.answer === 'Ja' || qa.answer === 'Nein' || qa.answer === 'Test') {
        formattedAnswer = `"${qa.answer}"`;
      }

      if (qa.question === "Praktische Probleme" || qa.question === "Familiäre Probleme" || qa.question === "Emotionale Probleme") {
        currentSection = qa.question;
        page.drawText(`${qa.question}:`, {
          x: 50,
          y: page.getHeight() - 50 - yOffset,
          size: 12,
          font,
        });
        yOffset += 40;
        continue;
      }

      const needsIndent = [
        'Wohnsituation',
        'Versicherung',
        'Arbeit/Schule',
        'Beförderung/Transport',
        'Kinderbetreuung',
        'Im Umgang mit dem Partner',
        'Im Umgang mit den Kindern',
        'Haben Sie minderjährige Kinder',
        'Sorgen',
        'Ängste',
        'Traurigkeit',
      ].some(item => qa.question.includes(item));

      const xOffset = needsIndent ? 100 : 50;

      // Draw question (bold)
      page.drawText(`${qa.question}`, {
        x: xOffset,
        y: page.getHeight() - 50 - yOffset,
        size: 12,
        font,
      });

      // Calculate width of question to position answer
      const questionWidth = font.widthOfTextAtSize(`${qa.question}`, 12);

      // Draw answer (regular)
      page.drawText(`: ${formattedAnswer}`, {
        x: xOffset + questionWidth,
        y: page.getHeight() - 50 - yOffset,
        size: 12,
        font: regularFont,
      });

      yOffset += 30;
    }

    const pdfBytes = await pdfDoc.save();
    const pdfPath = path.join(uploadsDir, `${actualFallnummer}.pdf`);
    await fs.writeFile(pdfPath, pdfBytes);

    return {
      docxPath,
      pdfPath,
    };
  } catch (error) {
    console.error('Error generating document:', error);
    throw error;
  }
}