import nodemailer from 'nodemailer';
import { SmtpSettings } from '@shared/schema';
import { storage } from './storage';

let transporter = nodemailer.createTransport({
  host: process.env.SMTP_HOST || 'smtp.gmail.com',
  port: parseInt(process.env.SMTP_PORT || '587'),
  secure: false,
  auth: {
    user: process.env.SMTP_USER,
    pass: process.env.SMTP_PASS,
  },
});

export function updateEmailConfig(settings: SmtpSettings) {
  transporter = nodemailer.createTransport({
    host: settings.host,
    port: settings.port,
    secure: settings.secure,
    auth: {
      user: settings.username,
      pass: settings.password,
    },
  });
}

interface EmailParams {
  to: string;
  subject: string;
  html: string;
}

export async function sendEmail(params: EmailParams): Promise<boolean> {
  try {
    const settings = await storage.getSmtpSettings();
    if (!settings) {
      console.error('SMTP settings not configured');
      return false;
    }

    await transporter.sendMail({
      from: settings.fromEmail,
      ...params
    });
    return true;
  } catch (error) {
    console.error('Email sending error:', error);
    return false;
  }
}