import { IStorage } from "./storage";
import { User, InsertUser, Webhook, InsertWebhook, SmtpSettings, WebhookResponse } from "@shared/schema";
import session from "express-session";
import createMemoryStore from "memorystore";
import { scrypt, randomBytes } from "crypto";
import { promisify } from "util";

const scryptAsync = promisify(scrypt);
const MemoryStore = createMemoryStore(session);

async function hashPassword(password: string) {
  const salt = randomBytes(16).toString("hex");
  const buf = (await scryptAsync(password, salt, 64)) as Buffer;
  return `${buf.toString("hex")}.${salt}`;
}

export class MemStorage implements IStorage {
  private users: Map<number, User>;
  private webhooks: Map<number, Webhook>;
  private smtpSettings: SmtpSettings | null = null;
  public sessionStore: session.Store;
  private currentUserId: number;
  private currentWebhookId: number;

  constructor() {
    this.users = new Map();
    this.webhooks = new Map();
    this.currentUserId = 1;
    this.currentWebhookId = 1;
    this.sessionStore = new MemoryStore({
      checkPeriod: 86400000,
    });

    // Initialize root admin asynchronously
    this.initializeRootAdmin().catch(console.error);
  }

  private async initializeRootAdmin() {
    const hashedPassword = await hashPassword("admin123");
    this.createUser({
      username: "admin",
      password: hashedPassword,
      email: "admin@example.com",
      isAdmin: true
    });
  }

  async getUser(id: number): Promise<User | undefined> {
    return this.users.get(id);
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    return Array.from(this.users.values()).find(
      (user) => user.username === username,
    );
  }

  async createUser(insertUser: InsertUser & { isAdmin?: boolean }): Promise<User> {
    const id = this.currentUserId++;
    const user: User = {
      ...insertUser,
      id,
      isAdmin: insertUser.isAdmin || false,
      createdAt: new Date()
    };
    this.users.set(id, user);
    return user;
  }

  async getWebhooks(userId: number): Promise<Webhook[]> {
    return Array.from(this.webhooks.values()).filter(
      (webhook) => webhook.userId === userId
    );
  }

  async getWebhook(id: number): Promise<Webhook | undefined> {
    return this.webhooks.get(id);
  }

  async getAllWebhooks(): Promise<Webhook[]> {
    return Array.from(this.webhooks.values());
  }

  async createWebhook(data: InsertWebhook): Promise<Webhook> {
    const id = this.currentWebhookId++;
    const webhook: Webhook = {
      id,
      ...data,
      responses: [],
      lastResponseTime: null,
      createdAt: new Date(),
    };
    this.webhooks.set(id, webhook);
    return webhook;
  }

  async updateWebhook(id: number, data: Partial<Webhook>): Promise<Webhook> {
    const webhook = this.webhooks.get(id);
    if (!webhook) {
      throw new Error("Webhook not found");
    }
    const updated = { ...webhook, ...data };
    this.webhooks.set(id, updated);
    return updated;
  }

  async addResponse(id: number, response: WebhookResponse): Promise<Webhook> {
    const webhook = this.webhooks.get(id);
    if (!webhook) {
      throw new Error("Webhook not found");
    }
    const responses = [...webhook.responses, response];
    const updated = {
      ...webhook,
      responses,
      lastResponseTime: response.timestamp,
    };
    this.webhooks.set(id, updated);
    return updated;
  }


  async deleteWebhook(id: number): Promise<boolean> {
    return this.webhooks.delete(id);
  }

  async getSmtpSettings(): Promise<SmtpSettings | null> {
    return this.smtpSettings;
  }

  async updateSmtpSettings(settings: SmtpSettings): Promise<SmtpSettings> {
    this.smtpSettings = settings;
    return settings;
  }
}

export const storage = new MemStorage();