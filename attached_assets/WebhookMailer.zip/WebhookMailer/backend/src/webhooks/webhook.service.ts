import { Injectable, NotFoundException, UnauthorizedException } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { Repository } from 'typeorm';
import { WebhookEntity, WebhookResponse } from './webhook.entity';
import { CreateWebhookDto } from './dto/create-webhook.dto';
import { UpdateWebhookDto } from './dto/update-webhook.dto';
import { WebhookGateway } from './webhook.gateway';
import { EmailService } from '../email/email.service';

@Injectable()
export class WebhookService {
  constructor(
    @InjectRepository(WebhookEntity)
    private webhookRepository: Repository<WebhookEntity>,
    private webhookGateway: WebhookGateway,
    private emailService: EmailService,
  ) {}

  async create(createWebhookDto: CreateWebhookDto, userId: number) {
    const webhook = this.webhookRepository.create({
      ...createWebhookDto,
      userId,
    });
    const saved = await this.webhookRepository.save(webhook);
    this.webhookGateway.broadcastUpdate();
    return saved;
  }

  findAllByUser(userId: number) {
    return this.webhookRepository.find({
      where: { userId },
      order: { id: 'DESC' },
    });
  }

  async findOne(id: number, userId: number) {
    const webhook = await this.webhookRepository.findOne({
      where: { id, userId },
    });
    if (!webhook) {
      throw new NotFoundException('Webhook not found');
    }
    return webhook;
  }

  async update(id: number, updateWebhookDto: UpdateWebhookDto, userId: number) {
    const webhook = await this.findOne(id, userId);
    const updated = await this.webhookRepository.save({
      ...webhook,
      ...updateWebhookDto,
    });
    this.webhookGateway.broadcastUpdate();
    return updated;
  }

  async remove(id: number, userId: number) {
    const webhook = await this.findOne(id, userId);
    await this.webhookRepository.remove(webhook);
    this.webhookGateway.broadcastUpdate();
  }

  async testWebhook(id: number, userId: number) {
    const webhook = await this.findOne(id, userId);
    return this.emailService.sendEmail({
      to: webhook.recipientEmail,
      subject: `[TEST] ${webhook.emailSubject}`,
      html: webhook.testMessage || "This is a test message from your webhook.",
    });
  }

  async deleteResponse(id: number, index: number, userId: number) {
    const webhook = await this.findOne(id, userId);
    
    if (!webhook.responses || index >= webhook.responses.length) {
      throw new NotFoundException('Response not found');
    }

    webhook.responses.splice(index, 1);
    await this.webhookRepository.save(webhook);
    this.webhookGateway.broadcastUpdate();
  }

  async handleWebhookResponse(id: number, formResponse: any) {
    const webhook = await this.webhookRepository.findOne({
      where: { id },
    });

    if (!webhook || !webhook.active) {
      return;
    }

    // Transform and save response
    const response: WebhookResponse = {
      answers: formResponse.answers.map(answer => ({
        question: answer.question,
        answer: answer.answer,
      })),
      timestamp: new Date().toISOString(),
      fallnummer: formResponse.fallnummer,
      docxPath: formResponse.docxPath,
      pdfPath: formResponse.pdfPath,
    };

    webhook.responses = [...(webhook.responses || []), response];
    webhook.lastResponseTime = response.timestamp;

    await this.webhookRepository.save(webhook);
    this.webhookGateway.broadcastUpdate();

    // Send email notification
    await this.emailService.sendEmail({
      to: webhook.recipientEmail,
      subject: webhook.emailSubject,
      html: this.generateEmailHtml(response),
    });
  }

  private generateEmailHtml(response: WebhookResponse): string {
    return `
      <h2>Neue Formular-Einreichung</h2>
      <p>Fallnummer: ${response.fallnummer}</p>
      <ul>
        ${response.answers.map(a => `
          <li><strong>${a.question}:</strong> ${a.answer}</li>
        `).join('')}
      </ul>
    `;
  }
}
