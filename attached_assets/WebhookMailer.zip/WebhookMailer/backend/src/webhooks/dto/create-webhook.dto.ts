import { IsString, IsEmail, IsOptional, MinLength } from 'class-validator';

export class CreateWebhookDto {
  @IsString()
  @MinLength(1, { message: 'Name is required' })
  name: string;

  @IsString()
  @MinLength(1, { message: 'Typeform ID is required' })
  typeformId: string;

  @IsEmail({}, { message: 'Valid email is required' })
  recipientEmail: string;

  @IsString()
  @MinLength(1, { message: 'Email subject is required' })
  emailSubject: string;

  @IsString()
  @IsOptional()
  testMessage?: string;
}
