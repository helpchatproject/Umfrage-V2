import { Module } from '@nestjs/common';
import { TypeOrmModule } from '@nestjs/typeorm';
import { WebhookController } from './webhook.controller';
import { WebhookService } from './webhook.service';
import { WebhookEntity } from './webhook.entity';
import { WebhookGateway } from './webhook.gateway';

@Module({
  imports: [TypeOrmModule.forFeature([WebhookEntity])],
  controllers: [WebhookController],
  providers: [WebhookService, WebhookGateway],
  exports: [WebhookService],
})
export class WebhookModule {}
