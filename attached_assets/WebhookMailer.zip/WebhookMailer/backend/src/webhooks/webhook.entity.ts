import { Entity, Column, PrimaryGeneratedColumn, ManyToOne } from 'typeorm';
import { User } from '../users/user.entity';

@Entity('webhooks')
export class WebhookEntity {
  @PrimaryGeneratedColumn()
  id: number;

  @Column()
  name: string;

  @Column()
  typeformId: string;

  @Column()
  recipientEmail: string;

  @Column()
  emailSubject: string;

  @Column({ nullable: true })
  testMessage: string;

  @Column({ default: true })
  active: boolean;

  @Column('jsonb', { nullable: true, default: [] })
  responses: WebhookResponse[];

  @Column({ nullable: true })
  lastResponseTime: string;

  @ManyToOne(() => User, user => user.webhooks)
  user: User;

  @Column()
  userId: number;
}

export interface WebhookResponse {
  answers: {
    question: string;
    answer: string;
  }[];
  timestamp: string;
  fallnummer: string;
  docxPath?: string;
  pdfPath?: string;
}
