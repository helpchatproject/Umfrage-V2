import { Controller, Get, Post, Body, Param, Delete, UseGuards, Req, Patch } from '@nestjs/common';
import { WebhookService } from './webhook.service';
import { CreateWebhookDto } from './dto/create-webhook.dto';
import { UpdateWebhookDto } from './dto/update-webhook.dto';
import { JwtAuthGuard } from '../auth/guards/jwt-auth.guard';
import { Request } from 'express';

@Controller('webhooks')
@UseGuards(JwtAuthGuard)
export class WebhookController {
  constructor(private readonly webhookService: WebhookService) {}

  @Post()
  create(@Body() createWebhookDto: CreateWebhookDto, @Req() req: Request) {
    return this.webhookService.create(createWebhookDto, req.user['id']);
  }

  @Get()
  findAll(@Req() req: Request) {
    return this.webhookService.findAllByUser(req.user['id']);
  }

  @Get(':id')
  findOne(@Param('id') id: string, @Req() req: Request) {
    return this.webhookService.findOne(+id, req.user['id']);
  }

  @Patch(':id')
  update(@Param('id') id: string, @Body() updateWebhookDto: UpdateWebhookDto, @Req() req: Request) {
    return this.webhookService.update(+id, updateWebhookDto, req.user['id']);
  }

  @Delete(':id')
  remove(@Param('id') id: string, @Req() req: Request) {
    return this.webhookService.remove(+id, req.user['id']);
  }

  @Post(':id/test')
  async testWebhook(@Param('id') id: string, @Req() req: Request) {
    return this.webhookService.testWebhook(+id, req.user['id']);
  }

  @Delete(':id/responses/:index')
  async deleteResponse(
    @Param('id') id: string,
    @Param('index') index: string,
    @Req() req: Request,
  ) {
    return this.webhookService.deleteResponse(+id, +index, req.user['id']);
  }
}
