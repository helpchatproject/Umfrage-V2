import { Injectable, NotFoundException, UnauthorizedException } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { Repository } from 'typeorm';
import { UserEntity } from './user.entity';
import * as bcrypt from 'bcrypt';
import { CreateUserDto } from './dto/create-user.dto';
import { UpdateUserDto } from './dto/update-user.dto';

@Injectable()
export class UserService {
  constructor(
    @InjectRepository(UserEntity)
    private userRepository: Repository<UserEntity>,
  ) {}

  async findAll(currentUser: UserEntity): Promise<UserEntity[]> {
    if (currentUser.role !== 'admin') {
      throw new UnauthorizedException('Only admins can view all users');
    }
    return this.userRepository.find();
  }

  async findOne(id: number, currentUser: UserEntity): Promise<UserEntity> {
    const user = await this.userRepository.findOne({ where: { id } });
    if (!user) {
      throw new NotFoundException('User not found');
    }
    
    if (currentUser.role !== 'admin' && currentUser.id !== id) {
      throw new UnauthorizedException('You can only view your own profile');
    }
    
    return user;
  }

  async create(createUserDto: CreateUserDto, currentUser: UserEntity): Promise<UserEntity> {
    if (currentUser.role !== 'admin') {
      throw new UnauthorizedException('Only admins can create new users');
    }

    const hashedPassword = await bcrypt.hash(createUserDto.password, 10);
    const user = this.userRepository.create({
      ...createUserDto,
      password: hashedPassword,
    });

    return this.userRepository.save(user);
  }

  async update(id: number, updateUserDto: UpdateUserDto, currentUser: UserEntity): Promise<UserEntity> {
    const user = await this.findOne(id, currentUser);
    
    if (currentUser.role !== 'admin' && currentUser.id !== id) {
      throw new UnauthorizedException('You can only update your own profile');
    }

    if (updateUserDto.password) {
      updateUserDto.password = await bcrypt.hash(updateUserDto.password, 10);
    }

    // Prevent non-admins from changing roles
    if (currentUser.role !== 'admin') {
      delete updateUserDto.role;
    }

    const updated = await this.userRepository.save({
      ...user,
      ...updateUserDto,
      updatedAt: new Date(),
    });

    return updated;
  }

  async toggleActive(id: number, currentUser: UserEntity): Promise<UserEntity> {
    if (currentUser.role !== 'admin') {
      throw new UnauthorizedException('Only admins can activate/deactivate users');
    }

    const user = await this.findOne(id, currentUser);
    user.isActive = !user.isActive;
    return this.userRepository.save(user);
  }
}
