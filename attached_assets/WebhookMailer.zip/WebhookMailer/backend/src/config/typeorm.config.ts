import { TypeOrmModuleOptions } from '@nestjs/typeorm';
import { WebhookEntity } from '../webhooks/webhook.entity';
import { UserEntity } from '../users/user.entity';

export const typeOrmConfig: TypeOrmModuleOptions = {
  type: 'postgres',
  url: process.env.DATABASE_URL,
  entities: [WebhookEntity, UserEntity],
  synchronize: true, // Nur für Entwicklung!
  logging: true,
};
