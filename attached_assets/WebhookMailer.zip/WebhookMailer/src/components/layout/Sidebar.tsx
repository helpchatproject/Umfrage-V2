import { useEffect, useRef } from 'react';
import { useRouter } from 'next/router';
import Link from 'next/link';
import { BarChart3, Users, Webhook, Settings } from 'lucide-react';
import { useAuth } from '@/hooks/use-auth';

interface SidebarProps {
  sidebarOpen: boolean;
  setSidebarOpen: (open: boolean) => void;
}

const Sidebar = ({ sidebarOpen, setSidebarOpen }: SidebarProps) => {
  const router = useRouter();
  const { user } = useAuth();
  const trigger = useRef<any>(null);
  const sidebar = useRef<any>(null);

  // close on click outside
  useEffect(() => {
    const clickHandler = ({ target }: MouseEvent) => {
      if (!sidebar.current || !trigger.current) return;
      if (
        !sidebarOpen ||
        sidebar.current.contains(target) ||
        trigger.current.contains(target)
      )
        return;
      setSidebarOpen(false);
    };
    document.addEventListener('click', clickHandler);
    return () => document.removeEventListener('click', clickHandler);
  });

  const menuItems = [
    {
      title: 'Dashboard',
      icon: <BarChart3 className="h-6 w-6" />,
      link: '/dashboard',
    },
    {
      title: 'Webhooks',
      icon: <Webhook className="h-6 w-6" />,
      link: '/webhooks',
    },
    {
      title: 'Users',
      icon: <Users className="h-6 w-6" />,
      link: '/users',
      adminOnly: true,
    },
    {
      title: 'Settings',
      icon: <Settings className="h-6 w-6" />,
      link: '/settings',
    },
  ];

  return (
    <aside
      id="sidebar"
      ref={sidebar}
      className={`absolute left-0 top-0 z-9999 flex h-screen w-72.5 flex-col overflow-y-hidden bg-white duration-300 ease-linear dark:bg-boxdark lg:static lg:translate-x-0 ${
        sidebarOpen ? 'translate-x-0' : '-translate-x-full'
      }`}
    >
      {/* Sidebar Header */}
      <div className="flex items-center justify-between gap-2 px-6 py-5.5 lg:py-6.5">
        <Link href="/dashboard">
          <div className="flex items-center gap-2">
            <Webhook className="h-8 w-8 text-primary" />
            <span className="text-xl font-semibold text-black dark:text-white">
              Webhook Manager
            </span>
          </div>
        </Link>
      </div>

      <div className="flex flex-col overflow-y-auto duration-300 ease-linear">
        {/* Navigation Menu */}
        <nav className="px-4 py-4 lg:px-6">
          <div className="mb-6 flex items-center justify-between">
            <h3 className="text-sm font-semibold text-bodydark2">MENU</h3>
          </div>

          {/* Menu Items */}
          <div className="flex flex-col gap-2">
            {menuItems.map((item) => {
              if (item.adminOnly && user?.role !== 'admin') return null;

              return (
                <Link
                  key={item.link}
                  href={item.link}
                  className={`group relative flex items-center gap-2.5 rounded-sm py-2 px-4 font-medium duration-300 ease-in-out hover:bg-graydark dark:hover:bg-meta-4 ${
                    router.pathname === item.link
                      ? 'bg-graydark dark:bg-meta-4'
                      : ''
                  }`}
                >
                  {item.icon}
                  {item.title}
                </Link>
              );
            })}
          </div>
        </nav>
      </div>
    </aside>
  );
};

export default Sidebar;