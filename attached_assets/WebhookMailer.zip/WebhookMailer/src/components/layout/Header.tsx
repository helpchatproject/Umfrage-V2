import { useEffect, useState } from 'react';
import { useRouter } from 'next/router';
import { Bell, Settings, LogOut } from 'lucide-react';
import { useAuth } from '@/hooks/use-auth';
import { Button } from '@/components/ui/button';

interface HeaderProps {
  sidebarOpen: boolean;
  setSidebarOpen: (open: boolean) => void;
}

const Header = ({ sidebarOpen, setSidebarOpen }: HeaderProps) => {
  const router = useRouter();
  const { logoutMutation } = useAuth();

  // Sticky Header
  const [sticky, setSticky] = useState(false);
  useEffect(() => {
    window.addEventListener('scroll', () => {
      setSticky(window.scrollY > 0);
    });
  }, []);

  return (
    <header
      className={`sticky top-0 z-999 flex w-full bg-white drop-shadow-1 dark:bg-boxdark dark:drop-shadow-none ${
        sticky ? 'shadow-2' : ''
      }`}
    >
      <div className="flex flex-grow items-center justify-between px-4 py-4 shadow-2">
        <div className="flex items-center gap-2">
          <h2 className="text-xl font-bold text-black dark:text-white">
            Webhook Manager
          </h2>
        </div>

        <div className="flex items-center gap-3">
          <Button
            variant="outline"
            size="sm"
            onClick={() => router.push('/webhooks')}
            className="gap-2"
          >
            <Bell className="h-4 w-4" />
            Manage Webhooks
          </Button>

          <Button
            variant="outline"
            size="sm"
            onClick={() => router.push('/settings')}
            className="gap-2"
          >
            <Settings className="h-4 w-4" />
            SMTP Settings
          </Button>

          <Button
            variant="outline"
            size="sm"
            onClick={() => logoutMutation.mutate()}
            className="gap-2"
          >
            <LogOut className="h-4 w-4" />
            Logout
          </Button>
        </div>
      </div>
    </header>
  );
};

export default Header;