import { useState } from "react";
import { Link, useLocation } from "wouter";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { ArrowLeft, Plus, Eye, Edit, Copy, Send } from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import { useQuery } from "@tanstack/react-query";

export default function WebhooksPage() {
  const [_, navigate] = useLocation();
  const { toast } = useToast();

  // Fetch webhooks data
  const { data: webhooks, isLoading } = useQuery({
    queryKey: ['/api/webhooks'],
  });

  const copyToClipboard = async (webhookId: string) => {
    try {
      const webhookUrl = `${window.location.origin}/api/webhooks/${webhookId}/receive`;
      await navigator.clipboard.writeText(webhookUrl);
      toast({
        title: "URL kopiert",
        description: "Die Webhook-URL wurde in die Zwischenablage kopiert.",
      });
    } catch (err) {
      toast({
        title: "Fehler",
        description: "Die URL konnte nicht kopiert werden.",
        variant: "destructive",
      });
    }
  };

  return (
    <div className="container mx-auto p-6">
      {/* Header */}
      <div className="flex items-center justify-between mb-6">
        <div className="flex items-center gap-4">
          <Link href="/dashboard">
            <Button variant="ghost" className="gap-2">
              <ArrowLeft className="h-4 w-4" />
              Back to Dashboard
            </Button>
          </Link>
        </div>
        <Link href="/webhooks/new">
          <Button className="gap-2">
            <Plus className="h-4 w-4" />
            Neuen Webhook erstellen
          </Button>
        </Link>
      </div>

      {/* Title */}
      <div className="mb-6">
        <h1 className="text-2xl font-semibold">Webhooks</h1>
        <p className="text-sm text-gray-500">
          Manage your Typeform webhook notifications
        </p>
      </div>

      {/* Webhooks Table */}
      <div className="rounded-md border">
        <Table>
          <TableHeader>
            <TableRow>
              <TableHead>Name</TableHead>
              <TableHead>Status</TableHead>
              <TableHead>Form ID</TableHead>
              <TableHead>Empfänger</TableHead>
              <TableHead>Letzte Antwort</TableHead>
              <TableHead className="text-right">Aktionen</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {webhooks?.map((webhook: any) => (
              <TableRow key={webhook.id}>
                <TableCell className="font-medium">{webhook.name}</TableCell>
                <TableCell>
                  <span className={`inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium ${
                    webhook.active ? 'bg-green-50 text-green-700' : 'bg-gray-50 text-gray-700'
                  }`}>
                    {webhook.active ? 'Aktiv' : 'Inaktiv'}
                  </span>
                </TableCell>
                <TableCell>{webhook.formId}</TableCell>
                <TableCell>{webhook.recipientEmail}</TableCell>
                <TableCell>
                  {webhook.lastResponseTime ? (
                    new Date(webhook.lastResponseTime).toLocaleString()
                  ) : (
                    <span className="text-gray-500">Keine Antworten</span>
                  )}
                </TableCell>
                <TableCell className="text-right">
                  <div className="flex justify-end gap-2">
                    <Link href={`/webhooks/${webhook.id}`}>
                      <Button
                        variant="outline"
                        size="sm"
                        className="gap-2"
                      >
                        <Eye className="h-4 w-4" />
                        Details
                      </Button>
                    </Link>
                    <Button
                      variant="outline"
                      size="sm"
                      onClick={() => copyToClipboard(webhook.id)}
                      className="gap-2"
                    >
                      <Copy className="h-4 w-4" />
                      URL
                    </Button>
                    <Link href={`/webhooks/${webhook.id}/edit`}>
                      <Button
                        variant="outline"
                        size="sm"
                        className="gap-2"
                      >
                        <Edit className="h-4 w-4" />
                        Bearbeiten
                      </Button>
                    </Link>
                    <Button
                      variant="outline"
                      size="sm"
                      onClick={() => {
                        // Test webhook functionality
                        console.log("Test webhook:", webhook.id);
                      }}
                      className="gap-2"
                    >
                      <Send className="h-4 w-4" />
                      Test
                    </Button>
                  </div>
                </TableCell>
              </TableRow>
            ))}
          </TableBody>
        </Table>
      </div>
    </div>
  );
}