import { useRouter } from 'next/router';
import { useAuth } from '@/hooks/use-auth';
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Bell } from 'lucide-react';

export default function Dashboard() {
  const router = useRouter();
  const { user } = useAuth();

  return (
    <div className="container mx-auto p-6">
      {/* Header Section */}
      <div className="flex flex-col gap-1 mb-8">
        <h1 className="text-2xl font-semibold">
          Welcome, {user?.username}!
        </h1>
        <p className="text-sm text-gray-500">
          Administrator Dashboard
        </p>
      </div>

      {/* Stats Section */}
      <div className="mb-6">
        <Card className="w-full max-w-[300px]">
          <CardContent className="p-6">
            <div className="flex flex-col">
              <h3 className="text-base font-medium mb-2">Active Webhooks</h3>
              <div className="flex items-center gap-2">
                <Bell className="h-5 w-5 text-gray-400" />
                <span className="text-2xl font-semibold">0</span>
                <span className="text-sm text-gray-500">out of 0 total</span>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Empty State */}
      <Card>
        <CardContent className="flex flex-col items-center justify-center py-12">
          <div className="mb-4">
            <Bell className="h-10 w-10 text-gray-400" />
          </div>
          <h3 className="text-lg font-medium mb-2">No Webhooks Yet</h3>
          <p className="text-sm text-gray-500 text-center mb-6 max-w-md">
            Get started by creating your first webhook to receive form notifications
          </p>
          <Button 
            onClick={() => router.push('/webhooks/new')} 
            variant="primary"
          >
            Create Webhook
          </Button>
        </CardContent>
      </Card>
    </div>
  );
}