import { useQuery } from "@tanstack/react-query";
import DashboardLayout from "@/components/layouts/dashboard-layout";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Loader2, Eye } from "lucide-react";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { useState } from "react";

// TypeScript Interfaces
interface Field {
  id: string;
  title: string;
}

interface Answer {
  field: {
    id: string;
  };
  type: string;
  text?: string;
  choice?: {
    label: string;
  };
  choices?: {
    labels: string[];
  };
  number?: number;
  boolean?: boolean;
  email?: string;
}

interface FormResponse {
  response_id?: string;
  token?: string;
  submitted_at?: string;
  definition?: {
    fields?: Field[];
  };
  answers?: Answer[];
}

export default function ApiTest() {
  const [selectedResponse, setSelectedResponse] = useState<FormResponse | null>(null);
  const formId = "Y3Z308AH"; // Typeform Form ID

  // API Fetch-Funktion
  const fetchResponses = async () => {
    const res = await fetch(`/api/typeform/forms/${formId}/responses`);
    if (!res.ok) throw new Error("Fehler beim Laden der Antworten");
    return res.json();
  };

  const { 
    data: response, 
    isLoading,
    error 
  } = useQuery({
    queryKey: [`/api/typeform/forms/${formId}/responses`],
    queryFn: fetchResponses,
    select: (data) => {
      console.log("Raw Response API Response:", JSON.stringify(data, null, 2));
      return Array.isArray(data) ? data[0] : data;
    },
  });

  // Hilfsfunktion zum Finden des Fragetexts
  const findQuestionTitle = (fieldId: string): string => {
    console.log("Suche Frage für Field ID:", fieldId);

    const field = response?.definition?.fields?.find(f => f.id === fieldId);
    if (field?.title) {
      console.log("Gefunden:", field.title);
      return field.title;
    }

    console.log("Keine Frage gefunden für ID:", fieldId);
    return "Unbekannte Frage";
  };

  if (isLoading) {
    return (
      <DashboardLayout>
        <div className="flex items-center justify-center min-h-[200px]">
          <Loader2 className="h-8 w-8 animate-spin" />
        </div>
      </DashboardLayout>
    );
  }

  if (error) {
    return (
      <DashboardLayout>
        <div>
          <h2 className="text-2xl font-bold tracking-tight">API Test</h2>
          <p className="text-red-500">Fehler beim Laden der Daten: {error.message}</p>
        </div>
      </DashboardLayout>
    );
  }

  if (!response) {
    return (
      <DashboardLayout>
        <div>
          <h2 className="text-2xl font-bold tracking-tight">API Test</h2>
          <p className="text-muted-foreground">Keine Daten verfügbar</p>
        </div>
      </DashboardLayout>
    );
  }

  // Hilfsfunktion zum Formatieren der Antworten
  const formatAnswer = (answer: Answer | undefined): string => {
    if (!answer) return "Keine Antwort";

    switch (answer.type) {
      case "text":
        return answer.text || "Keine Antwort";
      case "choice":
        return answer.choice?.label?.replace(/\*/g, "") || "Keine Auswahl";
      case "choices":
        return answer.choices?.labels?.join(", ") || "Keine Auswahl";
      case "number":
        return answer.number?.toString() || "Keine Antwort";
      case "boolean":
        return answer.boolean ? "Ja" : "Nein";
      case "email":
        return answer.email || "Keine Antwort";
      default:
        return "Keine Antwort";
    }
  };

  const answers = response.answers || [];
  console.log("Gefundene Antworten:", answers);

  return (
    <DashboardLayout>
      <div className="space-y-6">
        <div>
          <h2 className="text-2xl font-bold tracking-tight">API Test</h2>
          <p className="text-muted-foreground">
            Test der Typeform API mit Form ID: {formId}
          </p>
        </div>

        <Card>
          <CardHeader>
            <CardTitle>Formular Antworten</CardTitle>
          </CardHeader>
          <CardContent>
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Response ID</TableHead>
                  <TableHead>Eingereicht am</TableHead>
                  <TableHead>Aktionen</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                <TableRow>
                  <TableCell>
                    {response.response_id || "Keine ID"}
                  </TableCell>
                  <TableCell>
                    {response.submitted_at
                      ? new Date(response.submitted_at).toLocaleString("de-DE")
                      : "Kein Datum"}
                  </TableCell>
                  <TableCell>
                    <Button
                      variant="outline"
                      size="sm"
                      onClick={() => {
                        console.log("Setting selected response:", response);
                        setSelectedResponse(response);
                      }}
                    >
                      <Eye className="h-4 w-4 mr-2" />
                      Details
                    </Button>
                  </TableCell>
                </TableRow>
              </TableBody>
            </Table>
          </CardContent>
        </Card>
      </div>

      {/* Dialog für Fragen & Antworten */}
      <Dialog open={!!selectedResponse} onOpenChange={() => setSelectedResponse(null)}>
        <DialogContent className="max-w-2xl">
          <DialogHeader>
            <DialogTitle>Fragen und Antworten</DialogTitle>
          </DialogHeader>
          <div className="mt-4">
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Frage</TableHead>
                  <TableHead>Antwort</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {answers.map((answer) => {
                  const fieldId = answer.field.id;
                  const questionTitle = findQuestionTitle(fieldId);

                  return (
                    <TableRow key={fieldId}>
                      <TableCell>{questionTitle}</TableCell>
                      <TableCell>{formatAnswer(answer)}</TableCell>
                    </TableRow>
                  );
                })}
              </TableBody>
            </Table>
          </div>
        </DialogContent>
      </Dialog>
    </DashboardLayout>
  );
}