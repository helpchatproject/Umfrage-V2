import DashboardLayout from "@/components/layouts/dashboard-layout";
import { useQuery, useMutation } from "@tanstack/react-query";
import { Form, FormControl, FormField, FormItem, FormLabel, FormDescription } from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { appSettingsSchema, AppSettings } from "@shared/schema";
import { useToast } from "@/hooks/use-toast";
import { queryClient } from "@/lib/queryClient";
import { Loader2 } from "lucide-react";
import { useState } from "react";

export default function ApplicationSettings() {
  const { toast } = useToast();
  const [previewLogo, setPreviewLogo] = useState<string | null>(null);

  const { data: settings, isLoading } = useQuery<AppSettings>({
    queryKey: ["/api/app-settings"],
  });

  const form = useForm({
    resolver: zodResolver(appSettingsSchema),
    defaultValues: {
      companyName: settings?.companyName || "Medventi GmbH",
      logoUrl: settings?.logoUrl || "/Medventi_logo_colour.png",
    },
  });

  const mutation = useMutation({
    mutationFn: async (data: FormData) => {
      const res = await fetch("/api/app-settings", {
        method: "POST",
        body: data,
      });
      if (!res.ok) {
        const error = await res.json();
        throw new Error(error.message || "Ein Fehler ist aufgetreten");
      }
      return res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/app-settings"] });
      toast({
        title: "Einstellungen gespeichert",
        description: "Die Anwendungseinstellungen wurden erfolgreich aktualisiert.",
      });
    },
    onError: (error: Error) => {
      toast({
        title: "Fehler",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  const handleLogoChange = (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (file) {
      // Vorschau erstellen
      const reader = new FileReader();
      reader.onloadend = () => {
        setPreviewLogo(reader.result as string);
      };
      reader.readAsDataURL(file);
    }
  };

  const onSubmit = async (data: any) => {
    const formData = new FormData();
    formData.append('companyName', data.companyName);

    // Logo-Datei hinzufügen, wenn eine ausgewählt wurde
    const logoInput = document.querySelector<HTMLInputElement>('input[type="file"]');
    if (logoInput?.files?.[0]) {
      formData.append('logo', logoInput.files[0]);
    }

    mutation.mutate(formData);
  };

  if (isLoading) {
    return (
      <DashboardLayout>
        <div className="flex justify-center items-center h-full">
          <Loader2 className="h-8 w-8 animate-spin" />
        </div>
      </DashboardLayout>
    );
  }

  return (
    <DashboardLayout>
      <div className="max-w-2xl mx-auto">
        <h1 className="text-2xl font-bold mb-6">Anwendungseinstellungen</h1>

        <div className="bg-white rounded-lg shadow-sm p-6">
          <Form {...form}>
            <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6">
              <FormField
                control={form.control}
                name="companyName"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Firmenname</FormLabel>
                    <FormControl>
                      <Input {...field} />
                    </FormControl>
                    <FormDescription>
                      Dieser Name wird in der Navigation angezeigt
                    </FormDescription>
                  </FormItem>
                )}
              />

              <FormItem>
                <FormLabel>Logo</FormLabel>
                <div className="space-y-4">
                  <div className="flex items-center gap-4">
                    <img
                      src={previewLogo || settings?.logoUrl || "/Medventi_logo_colour.png"}
                      alt="Logo"
                      className="h-12 w-auto object-contain"
                    />
                    <div className="flex-1">
                      <Input
                        type="file"
                        accept="image/*"
                        onChange={handleLogoChange}
                        className="cursor-pointer"
                      />
                    </div>
                  </div>
                  <FormDescription>
                    Unterstützte Formate: PNG, JPG, GIF (max. 2MB)
                  </FormDescription>
                </div>
              </FormItem>

              <Button 
                type="submit" 
                disabled={mutation.isPending}
                className="bg-[#3B82F6] hover:bg-[#2563EB] h-11"
              >
                {mutation.isPending && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}
                Speichern
              </Button>
            </form>
          </Form>
        </div>
      </div>
    </DashboardLayout>
  );
}