// Anwendungskonstanten
export const DEFAULT_LOGO = "/Logo_no background.png";
export const DEFAULT_COMPANY_NAME = "Medventi GmbH";
